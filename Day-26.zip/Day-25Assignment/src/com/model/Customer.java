package com.model;

public class Customer {
	private int cid;
	private String  cname;
	private  double csalary;
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", csalary=" + csalary + "]";
	}
	public Customer(int cid, String cname, double csalary) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.csalary = csalary;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public double getCsalary() {
		return csalary;
	}
	public void setCsalary(double csalary) {
		this.csalary = csalary;
	}
	
}
