package com.src;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.CustomerDao;
import com.model.Customer;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		CustomerDao cdao=(CustomerDao) context.getBean("customerdao1");
		
		int status=cdao.saveCustomer(new Customer(20,"java spot",4000));
				
		if(status>0)
		{
			System.out.println("values got inserted");
		}
		else
		{
			System.out.println("unable to insert values");
		}

	 status=cdao.deleteCustomer(new Customer(25,"",0));
		
		if(status>0)
		{
			System.out.println("values got delete");
		}
		else
		{
			System.out.println("unable to delete");
	
		}
		boolean status1=cdao.saveCustomerbyPs(new Customer(2,"my god",3000));
		
		if(!status1)
			System.out.println("values inserted by prepared statement");
		else
			System.out.println("unsucuessfil insertion by preparedstatement");
		
		
boolean status2=((CustomerDao) cdao).UpdateCustomer(new Customer(2,"nice",0));
		if(!status2)
			System.out.println("updated");
		else
			System.out.println("not updated");
		
		List<Customer> l=cdao.getCustomers();
		 for(Customer b:l)
		 {
			 System.out.println(b);
		 }
}





	}

